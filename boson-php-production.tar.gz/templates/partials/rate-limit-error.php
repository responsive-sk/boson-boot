<div class="search-results-error">
    <?= $this->e($message ?? 'Too many requests. Please wait a moment.') ?>
</div>
