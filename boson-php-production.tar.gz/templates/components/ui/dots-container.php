<?php
/**
 * Dots Container Component - converted from Lit dots-container component
 * Simple decorative element with four corner dots
 */
?>

<div class="dots-container">
    <div class="dots-inner">
        <div class="dot top left"></div>
        <div class="dot top right"></div>
        <div class="dot bottom left"></div>
        <div class="dot bottom right"></div>
    </div>
</div>


