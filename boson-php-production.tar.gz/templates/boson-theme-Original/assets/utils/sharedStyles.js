import { unsafeCSS } from 'lit';
import typography from '../styles/typography.css?inline';

export const sharedStyles = unsafeCSS(typography);
